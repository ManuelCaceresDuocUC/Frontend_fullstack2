// src/app/checkout/page.tsx
"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCart, cartTotal } from "@/store/useCart";

const fmt = (n: number) =>
  n.toLocaleString("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 });

export default function CheckoutPage() {
  const router = useRouter();
  const { items, clear } = useCart();
  const subtotal = useMemo(() => cartTotal(items), [items]);
  const [shippingFee, setShippingFee] = useState(0); // ajusta si agregas métodos de envío
  const total = subtotal + shippingFee;

  // Si el carrito está vacío, fuera.
  useEffect(() => {
    if (items.length === 0) router.replace("/galeria");
  }, [items.length, router]);

  // --------- Form state ----------
  const [email, setEmail] = useState("");
  const [buyerName, setBuyerName] = useState("");
  const [phone, setPhone] = useState("");

  const [shippingStreet, setStreet] = useState("");
  const [shippingCity, setCity] = useState("");
  const [shippingRegion, setRegion] = useState("");
  const [shippingZip, setZip] = useState("");
  const [shippingNotes, setNotes] = useState("");

  const [agree, setAgree] = useState(false);
  const [loading, setLoading] = useState(false);
  const disabled = loading || items.length === 0 || !agree || !email || !buyerName || !shippingStreet || !shippingCity || !shippingRegion;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (disabled) return;

    try {
      setLoading(true);

      // payload mínimo para /api/checkout/init (ajusta si tu endpoint usa otro contrato)
      const payload = {
        email,
        buyerName,
        phone,
        shippingStreet,
        shippingCity,
        shippingRegion,
        shippingZip,
        shippingNotes,
        items: items.map(i => ({
    perfumeId: i.id,      // 👈 antes productId
    name: i.name,
    brand: i.brand,
    ml: i.ml ?? null,
    unitPrice: i.price,   // 👈 antes price
    qty: i.qty,
    image: i.image ?? null,
  })),
  subtotal,
  shippingFee,
  total,
  method: "MANUAL" as const, // placeholder hasta integrar WebPay/MercadoPago
      };

      const res = await fetch("/api/checkout/init", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error || "No se pudo crear el pedido");
      }

      const data: { orderId: string; redirectUrl?: string } = await res.json();

      clear(); // vacía carrito sólo si se creó el pedido
      if (data.redirectUrl) {
        window.location.href = data.redirectUrl; // cuando integres pasarela real
        return;
      }

      router.replace(`/gracias/${data.orderId}`);
    } catch (err) {
      alert((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="pt-28 md:pt-36 min-h-screen bg-white text-slate-900">
      <div className="mx-auto max-w-6xl px-4 md:px-8 pb-16">
        <h1 className="text-2xl md:text-3xl font-extrabold mb-6">Checkout</h1>

        <div className="grid md:grid-cols-[1fr_380px] gap-8">
          {/* --------- FORM --------- */}
          <form onSubmit={submit} className="space-y-6">
            {/* Contacto */}
            <section className="rounded-2xl border border-slate-200 p-4 md:p-6">
              <h2 className="font-semibold text-lg mb-4">Contacto</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm mb-1">Correo electrónico</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="tucorreo@dominio.cl"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm mb-1">Nombre y apellido</label>
                  <input
                    required
                    value={buyerName}
                    onChange={e => setBuyerName(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="Juan Pérez"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm mb-1">Teléfono (opcional)</label>
                  <input
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="+56 9 1234 5678"
                  />
                </div>
              </div>
            </section>

            {/* Envío */}
            <section className="rounded-2xl border border-slate-200 p-4 md:p-6">
              <h2 className="font-semibold text-lg mb-4">Dirección de envío</h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm mb-1">Calle y número</label>
                  <input
                    required
                    value={shippingStreet}
                    onChange={e => setStreet(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="Av. Siempre Viva 742"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">Ciudad</label>
                  <input
                    required
                    value={shippingCity}
                    onChange={e => setCity(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="Santiago"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">Región</label>
                  <input
                    required
                    value={shippingRegion}
                    onChange={e => setRegion(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="Metropolitana"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">Código postal (opcional)</label>
                  <input
                    value={shippingZip}
                    onChange={e => setZip(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    placeholder="0000000"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm mb-1">Notas (opcional)</label>
                  <textarea
                    value={shippingNotes}
                    onChange={e => setNotes(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 px-3 py-2"
                    rows={3}
                    placeholder="Instrucciones para el repartidor, horario, etc."
                  />
                </div>
              </div>
            </section>

            {/* Términos + pagar */}
            <section className="rounded-2xl border border-slate-200 p-4 md:p-6 space-y-4">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} />
                Estoy de acuerdo con los{" "}
                <Link href="/terminos" className="underline">Términos del servicio</Link>
              </label>

              <button
                type="submit"
                disabled={disabled}
                className={`w-full md:w-auto px-6 py-3 rounded-2xl font-semibold text-white
                ${disabled ? "bg-slate-400" : "bg-blue-600 hover:bg-blue-700"}`}
              >
                {loading ? "Procesando..." : "Pagar ahora"}
              </button>
            </section>
          </form>

          {/* --------- RESUMEN --------- */}
          <aside className="rounded-2xl border border-slate-200 p-4 md:p-6 h-max">
            <h2 className="font-semibold text-lg mb-4">Resumen</h2>

            <div className="space-y-4 max-h-[50vh] overflow-auto pr-1">
              {items.map(it => (
                <div key={it.id} className="flex items-center gap-3">
                  {it.image ? (
                    <div className="relative h-16 w-16 rounded overflow-hidden bg-slate-100">
                      <Image src={it.image} alt={it.name} fill className="object-cover" />
                    </div>
                  ) : (
                    <div className="h-16 w-16 rounded bg-slate-100" />
                  )}
                  <div className="flex-1">
                    <p className="text-sm font-medium">{it.brand} {it.name}</p>
                    <p className="text-xs text-slate-500">{it.ml ? `${it.ml} ml · ` : ""}x{it.qty}</p>
                  </div>
                  <div className="text-sm font-semibold">{fmt(it.price * it.qty)}</div>
                </div>
              ))}
            </div>

            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><span>Subtotal</span><span>{fmt(subtotal)}</span></div>
              <div className="flex justify-between"><span>Envío</span><span>{shippingFee ? fmt(shippingFee) : "Por calcular / $0"}</span></div>
              <div className="border-t my-2" />
              <div className="flex justify-between text-base font-extrabold">
                <span>Total</span><span>{fmt(total)}</span>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
