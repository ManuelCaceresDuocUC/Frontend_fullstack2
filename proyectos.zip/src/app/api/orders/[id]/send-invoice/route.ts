// src/app/api/orders/[id]/send-invoice/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { buildInvoicePDF } from "@/lib/invoice";
import { sendEmail } from "@/lib/sendEmail";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* =========================
 * Helpers de validación/ID
 * ========================= */
type Ctx = { params: { id: string } };

function isCtx(x: unknown): x is Ctx {
  return (
    typeof x === "object" &&
    x !== null &&
    "params" in x &&
    typeof (x as { params?: unknown }).params === "object" &&
    (x as { params: { id?: unknown } }).params !== null &&
    typeof (x as { params: { id?: unknown } }).params.id === "string"
  );
}

function makeInvoiceNumber(o: { id: string; createdAt: Date }) {
  return `B-${String(o.createdAt.getFullYear()).slice(-2)}${o.id.slice(0, 6).toUpperCase()}`;
}

function fallbackTracking(orderId: string, carrier: string | null) {
  const pref = carrier === "Bluexpress" ? "BX" : "DP";
  return `${pref}-${orderId.slice(0, 8).toUpperCase()}`;
}

/* ================
 * Handler principal
 * ================ */
export async function POST(_req: Request, ctx: unknown) {
  if (!isCtx(ctx)) return NextResponse.json({ error: "ID inválido" }, { status: 400 });
  const { id } = ctx.params;

  try {
    const o = await prisma.order.findUnique({
      where: { id },
      include: { items: true, shipment: true },
    });
    if (!o) return NextResponse.json({ error: "Orden no encontrada" }, { status: 404 });
    if (!(o.status === "PAID" || o.status === "FULFILLED")) {
      return NextResponse.json({ error: "La orden aún no está pagada" }, { status: 400 });
    }

    const carrier =
      o.shipment?.carrier ?? (o.shippingRegion === "Valparaíso" ? "Despacho propio" : "Bluexpress");
    const tracking = o.shipment?.tracking ?? fallbackTracking(o.id, carrier);
    const invoiceNumber = makeInvoiceNumber(o);

    const pdf = await buildInvoicePDF({
      orderId: o.id,
      number: invoiceNumber,
      buyerName: o.buyerName,
      email: o.email,
      items: o.items.map((i) => ({
        name: i.name,
        brand: i.brand,
        ml: i.ml,
        unitPrice: i.unitPrice,
        qty: i.qty,
      })),
      subtotal: o.subtotal,
      shippingFee: o.shippingFee,
      total: o.total,
      address: {
        street: o.shippingStreet,
        city: o.shippingCity,
        region: o.shippingRegion,
        zip: o.shippingZip ?? undefined,
      },
    });

    await sendEmail({
      to: o.email,
      subject: `Boleta N° ${invoiceNumber} - Orden ${o.id}`,
      html: `<p>Gracias por tu compra.</p>
             <p>Número de envío: <strong>${tracking}</strong> (${carrier})</p>
             <p>Adjuntamos tu boleta en PDF.</p>`,
      attachments: [
        { filename: `Boleta_${invoiceNumber}.pdf`, content: pdf, contentType: "application/pdf" },
      ],
    });

    await prisma.shipment.upsert({
      where: { orderId: o.id },
      update: { carrier, tracking },
      create: { orderId: o.id, carrier, tracking },
    });

    return NextResponse.json({ ok: true, invoiceNumber, tracking, carrier });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
