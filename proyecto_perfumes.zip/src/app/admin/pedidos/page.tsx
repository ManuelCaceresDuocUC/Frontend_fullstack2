// src/app/admin/pedidos/page.tsx
"use client";

import useSWR from "swr";

type PaymentSummary = { method?: string | null; status?: string | null } | null;
type ShipmentSummary = { tracking?: string | null; status?: string | null; carrier?: string | null } | null;
type ItemSummary = {
  id: string;
  perfumeId: string;
  name: string;
  brand: string;
  ml: number;
  unitPrice: number;
  qty: number;
};
type ShippingAddress = {
  street: string;
  number: string;
  commune: string;
  city: string;
  region: string;
  notes: string | null;
};

type Order = {
  id: string;
  createdAt: string;
  buyerName: string;
  email: string;
  total: number;
  status: string;
  payment?: PaymentSummary;
  shipment?: ShipmentSummary;
  shipping?: ShippingAddress | null;
  items?: ItemSummary[];
};

const fetcher = async (u: string): Promise<Order[]> => {
  const r = await fetch(u, { cache: "no-store" });
  if (!r.ok) throw new Error(await r.text());
  return (await r.json()) as Order[];
};

export default function AdminOrders() {
  const { data, error, mutate, isLoading } = useSWR<Order[], Error>("/api/admin/orders", fetcher, {
    refreshInterval: 10000,
  });

  if (error) return <main className="pt-28 px-4">Error: {error.message}</main>;
  if (isLoading || !data) return <main className="pt-28 px-4">Cargando…</main>;

  return (
    <main className="pt-28 px-4 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Pedidos</h1>
      <div className="overflow-x-auto rounded-2xl bg-white text-slate-900">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-100">
            <tr>
              <th className="p-2 text-left">Fecha</th>
              <th className="p-2 text-left">Cliente</th>
              <th className="p-2 text-left">Total</th>
              <th className="p-2 text-left">Estado</th>
              <th className="p-2 text-left">Pago</th>
              <th className="p-2 text-left">Envío</th>
              <th className="p-2">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {data.map((o: Order) => (
              <tr key={o.id} className="border-t">
                <td className="p-2">{new Date(o.createdAt).toLocaleString("es-CL")}</td>
                <td className="p-2">
                  {o.buyerName}
                  <br />
                  <span className="text-slate-500">{o.email}</span>
                </td>
                <td className="p-2">${o.total.toLocaleString("es-CL")}</td>
                <td className="p-2">{o.status}</td>
                <td className="p-2">
                  {o.payment?.method ?? "-"} / {o.payment?.status ?? "-"}
                </td>
                <td className="p-2">{o.shipment?.tracking ?? "-"}</td>
                <td className="p-2">
                  <button
                    className="px-3 py-1 rounded bg-emerald-600 text-white"
                    onClick={async () => {
                      const tracking = window.prompt("Tracking:");
                      if (!tracking) return;
                      await fetch(`/api/admin/orders/${o.id}`, {
                        method: "PATCH",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ shipmentStatus: "Despachado", tracking }),
                      });
                      mutate();
                    }}
                  >
                    Marcar despachado
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
