// src/app/api/admin/orders/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await prisma.order.findMany({
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        createdAt: true,
        buyerName: true,
        email: true,
        total: true,
        status: true,
        payment: { select: { method: true, status: true } },
        shipment: { select: { tracking: true, status: true, carrier: true } },
        shipping: {
          select: { street: true, number: true, commune: true, city: true, region: true, notes: true },
        },
        items: {
          select: { id: true, perfumeId: true, name: true, brand: true, ml: true, unitPrice: true, qty: true },
        },
      },
      take: 200,
    });

    return NextResponse.json(rows);
  } catch (e) {
    // mira el error exacto en consola
    console.error("GET /api/admin/orders error:", e);
    const msg = e instanceof Error ? e.message : String(e);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
