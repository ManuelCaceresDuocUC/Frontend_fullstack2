"use client";
import { useCart } from "@/components/cart/CartContext";

type Props = {
  id: string; name: string; brand: string;
  price: number; ml: number; image?: string; disabled?: boolean;
};
export default function AddToCartButton({ disabled, ...p }: Props) {
  const { add, open } = useCart();
  return (
    <button
      disabled={disabled}
      onClick={() => { add({ ...p, qty: 1 }); open(); }}
      className="px-5 py-3 rounded-2xl bg-amber-300 text-black font-semibold hover:bg-yellow-300 disabled:opacity-50"
    >
      Añadir al carrito
    </button>
  );
}
