"use client";
import { useCart } from "./CartContext";

export default function CartFab() {
  const { toggle, count } = useCart();
  const n = count();
  return (
    <button
      onClick={toggle}
      aria-label="Carrito"
      className="fixed bottom-5 right-5 z-50 rounded-full shadow-lg bg-amber-400 px-5 py-3 font-semibold"
    >
      Carrito {n > 0 ? `(${n})` : ""}
    </button>
  );
}
