declare module "xml-crypto" {
  interface SignedXmlOptions {
    idAttributes?: string[];
  }
}
