-- AlterTable
ALTER TABLE `Perfume` MODIFY `description` TEXT NULL,
    ALTER COLUMN `updatedAt` DROP DEFAULT;
