"use client";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useCart } from "./CartContext";

const fmt = (n: number) => n.toLocaleString("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 });

export default function CartSidebar() {
  const { state, close, remove, setQty, total, clear } = useCart();
  const router = useRouter();

  return (
    <>
      {/* Backdrop clickable */}
      {state.open && (
        <div onClick={close} className="fixed inset-0 z-40 bg-black/40" aria-hidden />
      )}

      <aside
        className={`fixed top-0 right-0 z-50 h-full w-[90%] max-w-sm bg-white text-slate-900 shadow-xl transition-transform ${state.open ? "translate-x-0" : "translate-x-full"}`}
        role="dialog"
        aria-modal="true"
      >
        <div className="p-4 border-b flex items-center justify-between">
          <h2 className="text-lg font-bold">Tu carrito</h2>
          <button onClick={close} aria-label="Cerrar" className="px-2 py-1 rounded hover:bg-slate-100">✕</button>
        </div>

        <div className="p-4 space-y-3 overflow-y-auto h-[calc(100%-160px)]">
          {state.items.length === 0 ? (
            <p className="text-sm text-slate-600">Aún no agregas productos.</p>
          ) : state.items.map(it => (
            <div key={it.id} className="flex gap-3 border rounded-lg p-2">
              {it.image ? (
                <div className="relative h-16 w-16 rounded overflow-hidden bg-slate-100">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={it.image} alt={it.name} className="h-full w-full object-cover" />
                </div>
              ) : <div className="h-16 w-16 bg-slate-100 rounded" />}

              <div className="flex-1">
                <div className="font-semibold">{it.brand} {it.name}</div>
                <div className="text-xs text-slate-500">{it.ml} ml</div>
                <div className="text-sm">{fmt(it.price)}</div>
                <div className="mt-1 flex items-center gap-2">
                  <label className="text-xs">Cant.</label>
                  <input
                    type="number"
                    min={1}
                    value={it.qty}
                    onChange={(e) => setQty(it.id, Number(e.target.value || 1))}
                    className="w-16 px-2 py-1 border rounded"
                  />
                  <button onClick={() => remove(it.id)} className="ml-auto text-sm text-red-600 hover:underline">
                    Quitar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t">
          <div className="flex justify-between mb-3">
            <span>Total</span>
            <strong>{fmt(total())}</strong>
          </div>
          <div className="flex gap-2">
            <button onClick={clear} className="flex-1 px-3 py-2 rounded border">Vaciar</button>
            <button
              onClick={() => { close(); router.push("/checkout"); }}
              className="flex-1 px-3 py-2 rounded bg-blue-600 text-white"
            >
              Revisar compra
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
