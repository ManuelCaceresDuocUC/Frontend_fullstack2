"use client";
import { ShoppingCart } from "lucide-react";
import { useCart, cartCount } from "@/store/useCart";

export default function CartFab() {
  const { items, toggle } = useCart();
  const count = cartCount(items);
  return (
    <button
      aria-label="Abrir carrito"
      onClick={toggle}
      className="fixed bottom-4 right-4 z-50 rounded-full shadow-lg bg-blue-600 text-white p-4"
    >
      <div className="relative">
        <ShoppingCart className="h-6 w-6" />
        {count > 0 && (
          <span className="absolute -top-2 -right-2 text-xs bg-amber-300 text-black rounded-full px-2 py-0.5">
            {count}
          </span>
        )}
      </div>
    </button>
  );
}
