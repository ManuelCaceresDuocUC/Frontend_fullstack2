// src/app/api/admin/orders/[id]/route.ts  (PATCH)
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function PATCH(_: Request, { params }: { params: { id: string } }) {
  const body = await _.json() as Partial<{ status: "PENDING"|"PAID"|"FULFILLED"|"CANCELLED"|"REFUNDED"; tracking: string; carrier: string; shipmentStatus: string; }>;
  const updates: any = {};
  if (body.status) updates.status = body.status;

  const tx: any[] = [];
  if (Object.keys(updates).length) tx.push(prisma.order.update({ where: { id: params.id }, data: updates }));
  if (body.tracking || body.carrier || body.shipmentStatus) {
    tx.push(prisma.shipment.upsert({
      where: { orderId: params.id },
      update: { tracking: body.tracking ?? undefined, carrier: body.carrier ?? undefined, status: body.shipmentStatus ?? undefined },
      create: { orderId: params.id, tracking: body.tracking ?? null, carrier: body.carrier ?? null, status: body.shipmentStatus ?? null },
    }));
  }
  await prisma.$transaction(tx);
  return NextResponse.json({ ok: true });
}
