// app/api/checkout/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type CartItem = { id: string; qty: number };
type Address = { street?: string; city?: string; region?: string; zip?: string; notes?: string };
type CheckoutPayload = {
  email: string;
  buyerName: string;
  phone?: string;
  address?: Address;
  items: CartItem[];
};
type PerfumeRow = {
  id: string;
  name: string;
  brand: string;
  ml: number;
  price: number;
};

export async function POST(req: Request) {
  try {
    const body: unknown = await req.json();
    const { email, buyerName, phone, address, items } = body as CheckoutPayload;

    if (!email || !buyerName) {
      return NextResponse.json({ error: "email y buyerName requeridos" }, { status: 400 });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: "items vacíos" }, { status: 400 });
    }

    const ids = items.map((it: CartItem) => it.id);
const perfumes: PerfumeRow[] = await prisma.perfume.findMany({
  where: { id: { in: ids } },
  select: { id: true, name: true, brand: true, ml: true, price: true },
});
    const itemsData = items.map((it) => {
  const p = perfumes.find((pp: PerfumeRow) => pp.id === it.id);
  if (!p) throw new Error(`Perfume ${it.id} no existe`);
  return {
    perfumeId: p.id,
    name: p.name,
    brand: p.brand,
    ml: p.ml,
    unitPrice: p.price,
    qty: it.qty,
  };
});
    const subtotal = itemsData.reduce((sum, it) => sum + it.unitPrice * it.qty, 0);
    const shippingFee = 0;
    const total = subtotal + shippingFee;

    const order = await prisma.order.create({
      data: {
        email,
        buyerName,
        phone: phone ?? "",
        shippingStreet: address?.street ?? "",
        shippingCity: address?.city ?? "",
        shippingRegion: address?.region ?? "",
        shippingZip: address?.zip ?? "",
        shippingNotes: address?.notes ?? "",
        subtotal,
        shippingFee,
        total,
        status: "PENDING",
        items: { create: itemsData },
        payment: { create: { method: "MANUAL", status: "INITIATED", amount: total } },
      },
      select: { id: true },
    });

    return NextResponse.json({ id: order.id });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
