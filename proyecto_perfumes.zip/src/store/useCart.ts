"use client";
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type CartItem = {
  id: string;
  name: string;
  brand: string;
  price: number;   // CLP por unidad
  ml?: number;
  image?: string;
  qty: number;
};

type CartState = {
  items: CartItem[];
  isOpen: boolean;
  add: (item: Omit<CartItem,"qty">, qty?: number) => void;
  inc: (id: string) => void;
  dec: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
  open: () => void;
  close: () => void;
  toggle: () => void;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,
      add: (item, qty = 1) => {
        const items = [...get().items];
        const i = items.findIndex(x => x.id === item.id);
        if (i >= 0) items[i] = { ...items[i], qty: items[i].qty + qty };
        else items.push({ ...item, qty });
        set({ items });
      },
      inc: (id) => set({ items: get().items.map(i => i.id === id ? { ...i, qty: i.qty + 1 } : i) }),
      dec: (id) => set({
        items: get().items
          .map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty - 1) } : i)
      }),
      remove: (id) => set({ items: get().items.filter(i => i.id !== id) }),
      clear: () => set({ items: [] }),
      open: () => set({ isOpen: true }),
      close: () => set({ isOpen: false }),
      toggle: () => set({ isOpen: !get().isOpen }),
    }),
    { name: "mafums-cart" }
  )
);

export const cartCount = (items: CartItem[]) => items.reduce((a, b) => a + b.qty, 0);
export const cartTotal = (items: CartItem[]) => items.reduce((a, b) => a + b.qty * b.price, 0);
