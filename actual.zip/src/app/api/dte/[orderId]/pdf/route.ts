// src/app/api/dte/[orderId]/pdf/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { buildInvoicePDF } from "@/lib/invoice";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_req: Request, context: unknown) {
  const { params } = context as { params: { orderId: string } };
  const id = params.orderId;

  const o = await prisma.order.findUnique({
    where: { id },
    include: { items: true, shipment: true },
  });
  if (!o) return NextResponse.json({ error: "Orden no encontrada" }, { status: 404 });

  const dte = await prisma.dte.findUnique({ where: { orderId: id } });
  const folioStr = dte
    ? `Folio SII: ${dte.folio}`
    : `Boleta provisoria: B-${String(o.createdAt.getFullYear()).slice(-2)}${o.id
        .slice(0, 6)
        .toUpperCase()}`;

  const pdf = await buildInvoicePDF({
    orderId: o.id,
    number: folioStr,
    buyerName: o.buyerName,
    email: o.email,
    items: o.items.map(i => ({
      name: i.name,
      brand: i.brand,
      ml: i.ml,
      unitPrice: i.unitPrice,
      qty: i.qty,
    })),
    subtotal: o.subtotal,
    shippingFee: o.shippingFee,
    total: o.total,
    address: {
      street: o.shippingStreet,
      city: o.shippingCity,
      region: o.shippingRegion,
      zip: o.shippingZip || undefined,
    },
  });

  const bytes = pdf instanceof Uint8Array ? pdf : new Uint8Array(pdf);
  const ab = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;

  return new Response(ab, {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="Boleta_${o.id}.pdf"`,
      "Cache-Control": "no-store",
      "Content-Length": String(bytes.byteLength),
    },
  });
}
