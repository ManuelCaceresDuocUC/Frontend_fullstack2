"use client";
import { createContext, useContext, useEffect, useMemo, useReducer } from "react";

export type CartItem = {
  id: string;
  name: string;
  brand: string;
  price: number;
  ml: number;
  image?: string;
  qty: number;
};

type CartState = { open: boolean; items: CartItem[] };

type Action =
  | { type: "OPEN" } | { type: "CLOSE" } | { type: "TOGGLE" }
  | { type: "ADD"; item: CartItem }
  | { type: "REMOVE"; id: string }
  | { type: "SET_QTY"; id: string; qty: number }
  | { type: "CLEAR" };

const KEY = "cart_v1";

function reducer(state: CartState, action: Action): CartState {
  switch (action.type) {
    case "OPEN": return { ...state, open: true };
    case "CLOSE": return { ...state, open: false };
    case "TOGGLE": return { ...state, open: !state.open };
    case "ADD": {
      const idx = state.items.findIndex(i => i.id === action.item.id);
      const items = [...state.items];
      if (idx >= 0) items[idx] = { ...items[idx], qty: items[idx].qty + action.item.qty };
      else items.push(action.item);
      return { ...state, items };
    }
    case "REMOVE": return { ...state, items: state.items.filter(i => i.id !== action.id) };
    case "SET_QTY": {
      const items = state.items.map(i => i.id === action.id ? { ...i, qty: Math.max(1, action.qty) } : i);
      return { ...state, items };
    }
    case "CLEAR": return { ...state, items: [] };
    default: return state;
  }
}

type CartContextValue = {
  state: CartState;
  add: (i: Omit<CartItem, "qty"> & { qty?: number }) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  open: () => void;
  close: () => void;
  toggle: () => void;
  count: () => number;
  total: () => number;
};

const Ctx = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, { open: false, items: [] });

  // load
  useEffect(() => {
    try {
      const raw = typeof window !== "undefined" ? window.localStorage.getItem(KEY) : null;
      if (raw) {
        const parsed = JSON.parse(raw) as CartState;
        if (Array.isArray(parsed.items)) {
          dispatch({ type: "CLEAR" });
          // re-hydrate
          parsed.items.forEach(it => dispatch({ type: "ADD", item: it }));
        }
      }
    } catch {}
  }, []);

  // persist
  useEffect(() => {
    try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
  }, [state]);

  const api: CartContextValue = useMemo(() => ({
    state,
    add: i => dispatch({ type: "ADD", item: { ...i, qty: i.qty ?? 1 } }),
    remove: id => dispatch({ type: "REMOVE", id }),
    setQty: (id, qty) => dispatch({ type: "SET_QTY", id, qty }),
    clear: () => dispatch({ type: "CLEAR" }),
    open: () => dispatch({ type: "OPEN" }),
    close: () => dispatch({ type: "CLOSE" }),
    toggle: () => dispatch({ type: "TOGGLE" }),
    count: () => state.items.reduce((s, it) => s + it.qty, 0),
    total: () => state.items.reduce((s, it) => s + it.qty * it.price, 0),
  }), [state]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
