import { defineConfig } from "vitest/config";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  test: {
    environment: "jsdom",
    setupFiles: ["./test/setup.ts"],   // ← relativo, no absoluto
    globals: true,
    css: false,
    environmentOptions: { jsdom: { url: "http://localhost/" } },
  },
});
