"use client";
import Image from "next/image";
import Link from "next/link";
import { X } from "lucide-react";
import { useCart, cartTotal } from "@/store/useCart";

const fmt = (n:number)=> n.toLocaleString("es-CL",{style:"currency",currency:"CLP",maximumFractionDigits:0});

export default function CartDrawer() {
  const { items, isOpen, close, inc, dec, remove } = useCart();
  const total = cartTotal(items);

  return (
    <div
      className={`fixed inset-0 z-40 ${isOpen ? "pointer-events-auto" : "pointer-events-none"}`}
      aria-hidden={!isOpen}
    >
      {/* backdrop */}
      <div
        className={`absolute inset-0 bg-black/40 transition-opacity ${isOpen ? "opacity-100" : "opacity-0"}`}
        onClick={close}
      />
      {/* panel */}
      <aside
        role="dialog"
        aria-label="Carrito"
        className={`absolute right-0 top-0 h-full w-[92%] sm:w-[420px] bg-white text-slate-900 shadow-xl transition-transform
                    ${isOpen ? "translate-x-0" : "translate-x-full"}`}
        onClick={(e)=>e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-bold text-lg">Tu carrito</h2>
          <button aria-label="Cerrar" onClick={close} className="p-2 rounded hover:bg-slate-100"><X /></button>
        </div>

        <div className="p-4 space-y-4 overflow-y-auto h-[calc(100%-180px)]">
          {items.length === 0 && <p className="text-sm text-slate-500">Vacío por ahora.</p>}
          {items.map(it => (
            <div key={it.id} className="flex gap-3 items-center">
              {it.image ? (
                <div className="relative h-16 w-16 rounded overflow-hidden bg-slate-100">
                  <Image src={it.image} alt={it.name} fill className="object-cover" />
                </div>
              ) : <div className="h-16 w-16 rounded bg-slate-100" />}
              <div className="flex-1">
                <p className="font-medium">{it.brand} {it.name}</p>
                <p className="text-sm text-slate-500">{it.ml ? `${it.ml} ml · `: ""}{fmt(it.price)}</p>
                <div className="mt-1 flex items-center gap-2">
                  <button onClick={()=>dec(it.id)} className="px-2 py-1 border rounded">−</button>
                  <span className="w-6 text-center">{it.qty}</span>
                  <button onClick={()=>inc(it.id)} className="px-2 py-1 border rounded">+</button>
                  <button onClick={()=>remove(it.id)} className="ml-auto text-sm text-red-600">Quitar</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-slate-600">Total</span>
            <span className="text-lg font-extrabold">{fmt(total)}</span>
          </div>
          <Link
            href="/checkout"
            onClick={()=>close()}
            className="block text-center w-full py-3 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700"
          >
            Revisar compra
          </Link>
        </div>
      </aside>
    </div>
  );
}
